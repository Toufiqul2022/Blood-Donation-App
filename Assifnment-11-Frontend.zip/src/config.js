// src/config.js
export const API_URL = "https://assignment-11-backend-xi.vercel.app"; // Backend URL
